package com.proj.demo.Service;

import java.util.LinkedList;
import java.util.List;

import com.proj.demo.Entity.ProductEntity;

public class ProductService {
	
	List<ProductEntity> cart =  new LinkedList<ProductEntity>();
	
	public List<ProductEntity> addProduct(List<ProductEntity> lst) {
		ProductEntity p4 = new ProductEntity();
		p4.setId(4);
		p4.setPname("Laptop");
		p4.setPdesc("Lenovo laptop");
		

		cart.add(p4);
		
		

		

		System.out.println(lst);
		
		
		//lst.g
		
		return cart;

		//System.out.println(lst);
		
		//cart.add(lst);
	}
	
	public void removeProduct() {
		
	}
	
	public List<ProductEntity> viewCartProduct() {
		
		//System.out.println("Items present in Your cart"+cart);
		return cart;
	}

}
