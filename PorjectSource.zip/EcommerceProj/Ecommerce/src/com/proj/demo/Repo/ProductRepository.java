package com.proj.demo.Repo;

import java.util.ArrayList;
import java.util.List;

import com.proj.demo.Entity.ProductEntity;

public class ProductRepository {
	
	
	List<ProductEntity> repo = new ArrayList<ProductEntity>();
	
	public List<ProductEntity> getOne(int index){
		

		System.out.println(index);
		List<ProductEntity> getOne = new ArrayList<ProductEntity>();
		System.out.println(repo.get(index-1));
		getOne.add(repo.get(index-1));
		
		return getOne; 
		
	}
	
	
	public List<ProductEntity> allProducts() {
		
		
		
		ProductEntity p1 = new ProductEntity();
		p1.setId(1);
		p1.setPname("Laptop");
		p1.setPdesc("Lenovo laptop");
		

		
		ProductEntity p2 = new ProductEntity();
		p2.setId(2);
		p2.setPname("Mobile");
		p2.setPdesc("Moto G5");
		

		
		ProductEntity p3 = new ProductEntity();
		p3.setId(3);
		p3.setPname("Desktop");
		p3.setPdesc("Samsung");
	

		
		ProductEntity p4 = new ProductEntity();
		p4.setId(4);
		p4.setPname("Laptop");
		p4.setPdesc("Lenovo laptop");
		

		repo.add(p1);

		repo.add(p2);

		repo.add(p3);

		repo.add(p4);
		
		return repo;
		
	}
	
	
	
	

	

}
