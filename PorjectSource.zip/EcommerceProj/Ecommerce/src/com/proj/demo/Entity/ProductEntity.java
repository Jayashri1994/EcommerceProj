package com.proj.demo.Entity;

public class ProductEntity {
	
	private int id;
	private String pname;
	private String pdesc;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPdesc() {
		return pdesc;
	}
	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}
	public ProductEntity(int id, String pname, String pdesc) {
		super();
		this.id = id;
		this.pname = pname;
		this.pdesc = pdesc;
	}
	public ProductEntity() {
		super();
	}
	@Override
	public String toString() {
		return "ProductEntity [id=" + id + ", pname=" + pname + ", pdesc=" + pdesc + "]";
	}
	 
	
	

}
