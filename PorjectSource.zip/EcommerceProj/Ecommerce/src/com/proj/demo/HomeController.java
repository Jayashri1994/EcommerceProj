package com.proj.demo;

import java.util.Scanner;

import com.proj.demo.Repo.ProductRepository;
import com.proj.demo.Service.ProductService;

public class HomeController {

	public static void main(String[] args) {
		System.out.println("Welcome to E- Commerce Site");
		
		System.out.println("List of product availble in the Store");
		
		
		ProductRepository prep = new ProductRepository();
		
		System.out.println(prep.allProducts());
		 
		
		System.out.println("Menu");
		System.out.println("Please select one option");
		System.out.println("1. ADD product into cart");
		System.out.println("2. Remove product from cart");
		System.out.println("3. View product present in your cart");
	
		Scanner sc = new Scanner(System.in);
		
		int input = sc.nextInt();
		
		
		
		if(input == 1) {
			System.out.println("Please enter the product ID to be added to the cart");
			
			int padd = sc.nextInt();
			
			ProductRepository pr = new ProductRepository();
			pr.allProducts();
			System.out.println("get"+pr.getOne(padd));
			
			ProductService ps = new ProductService();
			
			
		
			
			
			ps.addProduct(pr.getOne(padd));
			
			

			//ProductService ps = new ProductService();
			//System.out.println(ps.viewCartProduct());
			
		}
		else if(input == 2){
			System.out.println("Please enter the product ID to be removed from the cart");
			
			int pdel = sc.nextInt();
		}
		else if(input == 3) {
			ProductService ps = new ProductService();
			System.out.println(ps.viewCartProduct()); 
		
		}
		else {
			System.out.println("Please enter correct option value");
		}
	}

}
